#ifndef UTIL_H
#define UTIL_H

char *readLine();

#endif //UTIL_H
